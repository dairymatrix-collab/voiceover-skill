# Voiceover Skill Plugin

This package is a Claude Code Plugin with a portable `skills/voiceover-skill/` directory and a `.claude-plugin/plugin.json` manifest whose `skills` entry names that Skill directory. It is separate from the MiniMax Code 0.4 compatibility package, whose manifest points to a top-level `skills/SKILL.md` file.

Use the bundled Skill instructions for local setup and execution. Model weights and engine runtimes are not bundled. No installer hooks, MCP server, credentials, or native binaries are included.
