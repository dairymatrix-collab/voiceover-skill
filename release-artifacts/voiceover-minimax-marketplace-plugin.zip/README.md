# Voiceover Skill — MiniMax Agent Plugin submission package

This ZIP uses the native third-party MiniMax submission format. Its only Plugin manifest is `.minimax-plugin/plugin.json` at the ZIP root, and it references `skills/voiceover-skill/SKILL.md`. There is no wrapper directory and no MiniMax Code/Claude compatibility manifest mixed into this submission package.

The Skill invokes bundled Python scripts through an explicit interpreter. It contains no model weights, native binaries, secrets, install lifecycle hooks, Hooks, or MCP servers. Engine runtimes and model files remain separate and must be acquired under the resource gates described in `skills/voiceover-skill/SKILL.md`.
