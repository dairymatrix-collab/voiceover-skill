# Voiceover Skill — MiniMax Code compatibility package

This ZIP targets both MiniMax Code versions with their required parallel layouts: root `plugin.json` for Agent Plugins 1.0 / mcode 0.3.x, and `.claude-plugin/plugin.json` plus top-level `skills/SKILL.md` for mcode 0.4.0+. `skills/voiceover-skill/SKILL.md` is byte-identical to the top-level Skill entry point for the older runtime/validator.

This is a Code compatibility package, not a Marketplace submission ZIP. For third-party submission use the separate `voiceover-minimax-marketplace-plugin.zip`, which contains only the native `.minimax-plugin` entry point.

The Skill invokes bundled Python scripts through an explicit interpreter. It contains no model weights, native binaries, secrets, install lifecycle hooks, Hooks, or MCP servers.
